package com.spring.board.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.board.service.BoardService;
import com.spring.board.vo.BoardVo;

@Controller
public class BoardController {
	@Autowired
	private BoardService boardService;
	/*메뉴,게시판 전체 조회*/
	@RequestMapping("/board")
	public ModelAndView boardMain(@RequestParam HashMap<String,Object>map ) {
		//b_menu_id=MENU01&p_nowpage=1&p_pagecount=10&p_pagegrpnum=1
		
		ModelAndView mv = new ModelAndView();
		/*메뉴리스트*/
		List<BoardVo> MenuList = boardService.getMenuList(map);
		/*게시판리스트*/
		List<BoardVo> BoardList = boardService.getBoardList(map);

		BoardVo pageBoardVo = (BoardVo) map.get("pageBoardVo");
		
		mv.addObject("b_menu_id", map.get("b_menu_id"));
		
		mv.setViewName("/board/boardMain");
		mv.addObject("BoardList", BoardList);
		mv.addObject("MenuList", MenuList);
		mv.addObject("pageBoardVo", pageBoardVo);
		System.out.println("번호를 찾자!!" + BoardList);
		System.out.println("번호를 찾자!!" + MenuList);
		System.out.println("번호를 찾자!!" + pageBoardVo);
		return mv;
	}
	/*공지사항 확인View*/
	@RequestMapping("/board/ContentView")
	public ModelAndView ContentView(@RequestParam HashMap<String,Object>map) {
		ModelAndView mv = new ModelAndView();
		//b_idx = idx
		List<BoardVo> noticeView = boardService.noticeUpdateForm(map);
		BoardVo vo = noticeView.get(0);
		mv.setViewName("board/noticeContent");
		mv.addObject("noticeView", vo);
		
		return mv;
	}
	
	/*공지사항 조회*/
	@RequestMapping("/board/notice")
	public ModelAndView boardList(@RequestParam HashMap<String,Object>map) {
		//b_menu_id=MENU01
		ModelAndView mv = new ModelAndView();
		/*조회*/
		List<BoardVo> noticeWrite = boardService.noticeList(map);
		BoardVo vo = noticeWrite.get(0);
		
		mv.setViewName("/board/noticeWriteForm");
		mv.addObject("noticeWrite",vo);
		
		return mv;
	}
	
	/*공지사항 추가*/
	@RequestMapping("/board/noticeWrite")
	public String noticeWrite(@RequestParam HashMap<String,Object>map) {
		//b_menu_id=MENU01&b_writer=작성자,b_title, b_cont, b_bnum,b_lvl, b_step, b_nref
		/*추가*/
		boardService.noticeWrite(map);
		System.out.println("**************" + map);
		
		return "redirect:/board?b_menu_id="+map.get("b_menu_id")+"&p_nowpage=1&p_pagecount=10&p_pagegrpnum=1"; 
	}
	
	/*공지사항 삭제*/
	@RequestMapping("/board/notice/delete")
	public String noticeDelete(@RequestParam HashMap<String,Object>map) {
		//b_idx=글 번호
		boardService.noticeDelete(map);
		System.out.println("delete  map " + map);
		
		
		return "redirect:/board?b_menu_id="+map.get("b_menu_id")+"&p_nowpage=1&p_pagecount=10&p_pagegrpnum=1";
	}
	
	/*공지사항 수정 리스트*/
	@RequestMapping("/board/notice/updateForm")
	public ModelAndView noticeUpdateForm(@RequestParam HashMap<String,Object>map) {
		
		
		ModelAndView mv = new ModelAndView();
		//b_idx=  &b_menu_id= 
		List<BoardVo> noticeView = boardService.noticeUpdateForm(map);
		BoardVo vo = noticeView.get(0);
		mv.setViewName("board/noticeUpdateForm");
		mv.addObject("noticeView", vo);
		
		return mv;
	}
	/*공지사항 수정*/
	@RequestMapping("/board/notice/update")
	public String noticeUpdate(@RequestParam HashMap<String,Object>map) {
		System.out.println("공지사항 수정 리스트 확인 " + map );
		
		boardService.noticeUpdate(map);
		return "redirect:/board?b_menu_id="+map.get("b_menu_id")+"&p_nowpage=1&p_pagecount=10&p_pagegrpnum=1";
	}
	
	
	/*문의사항 boardMain에서 댓글달기 */ 
	/*답글쓰기는 noticeContent에서 ajax로 사실 쓰고싶음..ㅠㅠ*/
	@RequestMapping("/board/Question") //method=RequestMethod.POST
	public String SetQuestions(@RequestParam HashMap<String,Object>map) {
		
		boardService.SetCommnet(map);
		 
		System.out.println("문의사항 답글 : " + map);
		return "redirect:/board?b_menu_id="+map.get("b_menu_id")+"&p_nowpage=1&p_pagecount=10&p_pagegrpnum=1";
	}
	
	

}
