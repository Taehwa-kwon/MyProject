package com.spring.board.service.impl;

import com.spring.board.vo.BoardVo;

public class BoardPaging {
	private int p_nowpage; // 현재 페이지 정보 13
	private int p_pagecount; // 1페이지에 보여줄 자료 라인수
	
	private int p_prevnowpage; // 이전 페이지 정보
	private int p_nextnowpage; // 다음 페이지 정보
	
	private int p_recordcount; // 전체 자료수 50개 .. 
	private int p_totalpagecount; // 전체 페이지수, 1그룹 한 그룹당 당 총 개수 
	private int p_totalrecordpagecount;//10에서 끝나는게 아니라 1 ~ 9 까지 끝나는 경우를 계산하려고  
	
	private int p_pagestartnum; // 페이지 시작 번호 ( 단일 화면 )
	private int p_pageendnum; // 페이지 끝 번호 ( 단일 화면 )
	private int p_pagegrpnum; // 페이지그룹번호
	
	private boolean p_isshowpageprev; // ◀ ▶ 이거 표시
	private boolean p_isshowpagenext;
	
	public BoardPaging(int p_nowpage, int p_pagecount, int p_recordcount, int p_totalpagecount, int p_pagegrpnum) {
		this.p_nowpage = p_nowpage;
		this.p_pagecount = p_pagecount;
		this.p_recordcount = p_recordcount;
		this.p_totalpagecount = p_totalpagecount;
		this.p_pagegrpnum = p_pagegrpnum;
	}
	
	
	public int getP_nowpage() {
		return p_nowpage;
	}
	public void setP_nowpage(int p_nowpage) {
		this.p_nowpage = p_nowpage;
	}
	public int getP_pagecount() {
		return p_pagecount;
	}
	public void setP_pagecount(int p_pagecount) {
		this.p_pagecount = p_pagecount;
	}
	public int getP_prevnowpage() {
		return p_prevnowpage;
	}
	public void setP_prevnowpage(int p_prevnowpage) {
		this.p_prevnowpage = p_prevnowpage;
	}
	public int getP_nextnowpage() {
		return p_nextnowpage;
	}
	public void setP_nextnowpage(int p_nextnowpage) {
		this.p_nextnowpage = p_nextnowpage;
	}
	public int getP_recordcount() {
		return p_recordcount;
	}
	public void setP_recordcount(int p_recordcount) {
		this.p_recordcount = p_recordcount;
	}
	public int getP_totalpagecount() {
		return p_totalpagecount;
	}
	public void setP_totalpagecount(int p_totalpagecount) {
		this.p_totalpagecount = p_totalpagecount;
	}
	public int getP_totalrecordpagecount() {
		return p_totalrecordpagecount;
	}
	public void setP_totalrecordpagecount(int p_totalrecordpagecount) {
		this.p_totalrecordpagecount = p_totalrecordpagecount;
	}
	public int getP_pagestartnum() {
		return p_pagestartnum;
	}
	public void setP_pagestartnum(int p_pagestartnum) {
		this.p_pagestartnum = p_pagestartnum;
	}
	public int getP_pageendnum() {
		return p_pageendnum;
	}
	public void setP_pageendnum(int p_pageendnum) {
		this.p_pageendnum = p_pageendnum;
	}
	public int getP_pagegrpnum() {
		return p_pagegrpnum;
	}
	public void setP_pagegrpnum(int p_pagegrpnum) {
		this.p_pagegrpnum = p_pagegrpnum;
	}
	public boolean isP_isshowpageprev() {
		return p_isshowpageprev;
	}
	public void setP_isshowpageprev(boolean p_isshowpageprev) {
		this.p_isshowpageprev = p_isshowpageprev;
	}
	public boolean isP_isshowpagenext() {
		return p_isshowpagenext;
	}
	public void setP_isshowpagenext(boolean p_isshowpagenext) {
		this.p_isshowpagenext = p_isshowpagenext;
	}


	public BoardVo getBoardPagingInfo() {
		BoardVo vo = new BoardVo();
//	private int p_nowpage; // 현재 페이지 정보 13
//  private int p_pagecount; // 1페이지에 보여줄 자료 라인수
//	private int p_recordcount; // 전체 자료수 50개 .. 
//	private int p_totalpagecount; // 전체 페이지수, 1그룹 한 그룹당 당 총 개수 
//	private int p_totalrecordpagecount;//10에서 끝나는게 아니라 1 ~ 9 까지 끝나는 경우를 계산하려고  
		 
		this.p_totalrecordpagecount = (int) Math.ceil((double)p_recordcount/(double)p_pagecount);
		
		this.p_pagestartnum = (p_pagegrpnum-1) * p_totalpagecount+1;
		this.p_pageendnum = p_totalrecordpagecount < (p_pagegrpnum * p_totalpagecount)?p_totalrecordpagecount:(p_pagegrpnum*p_totalpagecount);
		
		if(p_pagestartnum == 1) p_isshowpageprev = false;
		else p_isshowpageprev = true;
		if(p_pageendnum >= p_totalrecordpagecount ) p_isshowpagenext = false;
		else p_isshowpagenext = true;
		
		this.p_prevnowpage = p_pagestartnum -1;
		this.p_nextnowpage = p_pageendnum +1;
		
		vo.setP_nowpage(this.p_nowpage);
		vo.setP_prevnowpage(this.p_prevnowpage);
		vo.setP_nextnowpage(this.p_nextnowpage);
		
		vo.setP_recordcount(this.p_recordcount);
		vo.setP_totalpagecount(this.p_totalpagecount);
		
		vo.setP_pagestartnum(this.p_pagestartnum);
		vo.setP_pageendnum(this.p_pageendnum);
		
		vo.setP_pagecount(this.p_pagecount);
		vo.setP_pagegrpnum(this.p_pagegrpnum);
		
		vo.setP_isshowpagenext(this.p_isshowpagenext);
		vo.setP_isshowpageprev(this.p_isshowpageprev);
		
		return vo;
	}
	
	
}
