package com.spring.admin.vo;

public class TicketsVo {
	
	//TICKETS
	int t_hour;
	int t_price;
	String t_id;
	String t_gubun;
	
	//TICKETS_BUY
	int tb_idx;
	String tb_time;
	
	//
	String u_id;
	String u_name;
	
	//COMMONS
	int com_lvl;
	String com_val;
	String com_id;
	String grp_id;
	String parent_id;
	
	
	
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public String getU_name() {
		return u_name;
	}
	public void setU_name(String u_name) {
		this.u_name = u_name;
	}
	public int getT_hour() {
		return t_hour;
	}
	public void setT_hour(int t_hour) {
		this.t_hour = t_hour;
	}
	public int getT_price() {
		return t_price;
	}
	public void setT_price(int t_price) {
		this.t_price = t_price;
	}
	public String getT_id() {
		return t_id;
	}
	public void setT_id(String t_id) {
		this.t_id = t_id;
	}
	public String getT_gubun() {
		return t_gubun;
	}
	public void setT_gubun(String t_gubun) {
		this.t_gubun = t_gubun;
	}
	public int getTb_idx() {
		return tb_idx;
	}
	public void setTb_idx(int tb_idx) {
		this.tb_idx = tb_idx;
	}
	public String getTb_time() {
		return tb_time;
	}
	public void setTb_time(String tb_time) {
		this.tb_time = tb_time;
	}
	public int getCom_lvl() {
		return com_lvl;
	}
	public void setCom_lvl(int com_lvl) {
		this.com_lvl = com_lvl;
	}
	public String getCom_val() {
		return com_val;
	}
	public void setCom_val(String com_val) {
		this.com_val = com_val;
	}
	public String getCom_id() {
		return com_id;
	}
	public void setCom_id(String com_id) {
		this.com_id = com_id;
	}
	public String getGrp_id() {
		return grp_id;
	}
	public void setGrp_id(String grp_id) {
		this.grp_id = grp_id;
	}
	public String getParent_id() {
		return parent_id;
	}
	public void setParent_id(String parent_id) {
		this.parent_id = parent_id;
	}
	@Override
	public String toString() {
		return "TicketsVo [t_hour=" + t_hour + ", t_price=" + t_price + ", t_id=" + t_id + ", t_gubun=" + t_gubun
				+ ", tb_idx=" + tb_idx + ", tb_time=" + tb_time + ", u_id=" + u_id + ", u_name=" + u_name + ", com_lvl="
				+ com_lvl + ", com_val=" + com_val + ", com_id=" + com_id + ", grp_id=" + grp_id + ", parent_id="
				+ parent_id + "]";
	}
	
	
	
	
	
	
	

}
