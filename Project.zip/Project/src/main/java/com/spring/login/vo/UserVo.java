package com.spring.login.vo;

public class UserVo {
   
   private int u_idx;
   private String u_id;
   private String u_pw;
   private String u_name;
   private int age;
   private String u_gender;
   private String u_tel;
   private String u_question;
   private String answer;
   private String d_id;
   private String com_val;
   private String s_id;
   private String tb_time;
   private int tb_price;
   private String sr_start_time;
   private int sr_use_time;
   private int tb_discount;
   private int t_price;
   
   private int sum_tb_time;
   private int sum_tb_price;
   private int sum_t_price;
   private int sum_tb_discount;
   private int sum_t_hour;
   private int sum_sr_use_time;
   private int left_hours;
   public int getU_idx() {
      return u_idx;
   }
   public void setU_idx(int u_idx) {
      this.u_idx = u_idx;
   }
   public String getU_id() {
      return u_id;
   }
   public void setU_id(String u_id) {
      this.u_id = u_id;
   }
   public String getU_pw() {
      return u_pw;
   }
   public void setU_pw(String u_pw) {
      this.u_pw = u_pw;
   }
   public String getU_name() {
      return u_name;
   }
   public void setU_name(String u_name) {
      this.u_name = u_name;
   }
   public int getAge() {
      return age;
   }
   public void setAge(int age) {
      this.age = age;
   }
   public String getU_gender() {
      return u_gender;
   }
   public void setU_gender(String u_gender) {
      this.u_gender = u_gender;
   }
   public String getU_tel() {
      return u_tel;
   }
   public void setU_tel(String u_tel) {
      this.u_tel = u_tel;
   }
   public String getU_question() {
      return u_question;
   }
   public void setU_question(String u_question) {
      this.u_question = u_question;
   }
   public String getAnswer() {
      return answer;
   }
   public void setAnswer(String answer) {
      this.answer = answer;
   }
   public String getD_id() {
      return d_id;
   }
   public void setD_id(String d_id) {
      this.d_id = d_id;
   }
   public String getCom_val() {
      return com_val;
   }
   public void setCom_val(String com_val) {
      this.com_val = com_val;
   }
   public String getS_id() {
      return s_id;
   }
   public void setS_id(String s_id) {
      this.s_id = s_id;
   }
   public String getTb_time() {
      return tb_time;
   }
   public void setTb_time(String tb_time) {
      this.tb_time = tb_time;
   }
   public int getTb_price() {
      return tb_price;
   }
   public void setTb_price(int tb_price) {
      this.tb_price = tb_price;
   }
   public String getSr_start_time() {
      return sr_start_time;
   }
   public void setSr_start_time(String sr_start_time) {
      this.sr_start_time = sr_start_time;
   }
   public int getSr_use_time() {
      return sr_use_time;
   }
   public void setSr_use_time(int sr_use_time) {
      this.sr_use_time = sr_use_time;
   }
   public int getTb_discount() {
      return tb_discount;
   }
   public void setTb_discount(int tb_discount) {
      this.tb_discount = tb_discount;
   }
   public int getT_price() {
      return t_price;
   }
   public void setT_price(int t_price) {
      this.t_price = t_price;
   }
   public int getSum_tb_time() {
      return sum_tb_time;
   }
   public void setSum_tb_time(int sum_tb_time) {
      this.sum_tb_time = sum_tb_time;
   }
   public int getSum_tb_price() {
      return sum_tb_price;
   }
   public void setSum_tb_price(int sum_tb_price) {
      this.sum_tb_price = sum_tb_price;
   }
   public int getSum_t_price() {
      return sum_t_price;
   }
   public void setSum_t_price(int sum_t_price) {
      this.sum_t_price = sum_t_price;
   }
   public int getSum_tb_discount() {
      return sum_tb_discount;
   }
   public void setSum_tb_discount(int sum_tb_discount) {
      this.sum_tb_discount = sum_tb_discount;
   }
   public int getSum_t_hour() {
      return sum_t_hour;
   }
   public void setSum_t_hour(int sum_t_hour) {
      this.sum_t_hour = sum_t_hour;
   }
   public int getSum_sr_use_time() {
      return sum_sr_use_time;
   }
   public void setSum_sr_use_time(int sum_sr_use_time) {
      this.sum_sr_use_time = sum_sr_use_time;
   }
   public int getLeft_hours() {
      return left_hours;
   }
   public void setLeft_hours(int left_hours) {
      this.left_hours = left_hours;
   }
   @Override
   public String toString() {
      return "MyPageVo [u_idx=" + u_idx + ", u_id=" + u_id + ", u_pw=" + u_pw + ", u_name=" + u_name + ", age=" + age
            + ", u_gender=" + u_gender + ", u_tel=" + u_tel + ", u_question=" + u_question + ", answer=" + answer
            + ", d_id=" + d_id + ", com_val=" + com_val + ", s_id=" + s_id + ", tb_time=" + tb_time + ", tb_price="
            + tb_price + ", sr_start_time=" + sr_start_time + ", sr_use_time=" + sr_use_time + ", tb_discount="
            + tb_discount + ", t_price=" + t_price + ", sum_tb_time=" + sum_tb_time + ", sum_tb_price="
            + sum_tb_price + ", sum_t_price=" + sum_t_price + ", sum_tb_discount=" + sum_tb_discount
            + ", sum_t_hour=" + sum_t_hour + ", sum_sr_use_time=" + sum_sr_use_time + ", left_hours=" + left_hours
            + "]";
   }
   
   

   
   
   
   
   
   
   
}