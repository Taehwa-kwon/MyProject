package com.spring.login.dao;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.spring.admin.vo.UsersVo;

public interface LoginDao {
	/*로그인 처리*/
	UsersVo login(HashMap<String, Object> map);
	
	
	int idCheck(String u_id);


	UsersVo getView(HashMap<String, Object> map);









	

	

	

	

	

}
