package com.spring.admin.service.impl;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.admin.dao.AdminDao;
import com.spring.admin.service.AdminService;
import com.spring.admin.vo.SeatsVo;
import com.spring.admin.vo.TicketsVo;
import com.spring.admin.vo.UsersVo;

@Service("adminService")

public class AdminServiceImpl implements AdminService {
	@Autowired
	private AdminDao adminDao;

	/* 회원 리스트 조회 */
	@Override
	public List<UsersVo> getList(HashMap<String, Object> map) {
		List<UsersVo> userList = adminDao.getList(map);
		return userList;
	}

	/* 회원 삭제 */
	@Override
	public void delete(HashMap<String, Object> map) {
		adminDao.delete(map);
	}

	/* 회원 수정 */
	@Override
	public void updateList(HashMap<String, Object> map) {
		adminDao.updateList(map);
	}

	/* 티켓 리스트 조회 */
	@Override
	public List<TicketsVo> getTicketList(HashMap<String, Object> map) {

		List<TicketsVo> ticketList = adminDao.getTicketList(map);
		return ticketList;
	}

	/* 티켓 리스트 삭제 */
	@Override
	public void delTicketList(HashMap<String, Object> map) {
		adminDao.delTicketList(map);

		/* 티켓 리스트 수정 */
	}

	@Override
	public void updateTicket(HashMap<String, Object> map) {
		adminDao.updateTicket(map);

	}

	/* 티켓 추가 */
	@Override
	public void addTicket(HashMap<String, Object> map) {
		adminDao.addTicket(map);

	}

	/*
	 * 열람실 리스트 조회
	 * 
	 * @Override public List<SeatsVo> getRoomList(HashMap<String, Object> map) {
	 * List<SeatsVo> roomList = adminDao.getRoomList(map);
	 * System.out.println(roomList); return roomList; }
	 */
	/* 좌석 리스트 조회 */
	@Override
	public List<SeatsVo> getSeats(HashMap<String, Object> map) {
		List<SeatsVo> seatList = adminDao.getSeatList(map);
		return seatList;
	}

	@Override
	public List<SeatsVo> getRooms(HashMap<String, Object> map) {
		List<SeatsVo> roomList = adminDao.getRooms(map);
		return roomList;
	}

	

	@Override
	public void updateSeat(HashMap<String, Object> map) {
		adminDao.updateSeat(map);
		
	}

	@Override
	public List<TicketsVo> getSaleList(HashMap<String, Object> map) {
		List<TicketsVo> saleList = adminDao.getSaleList(map);
		return saleList;
	}

	
	
	

}
