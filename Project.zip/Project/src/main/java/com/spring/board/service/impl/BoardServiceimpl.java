package com.spring.board.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.spring.board.dao.BoardDao;
import com.spring.board.service.BoardService;
import com.spring.board.vo.BoardVo;
import com.spring.board.vo.FilesVo;

@Service("boardService")
public class BoardServiceimpl implements BoardService {
	
	@Autowired
	private BoardDao boardDao;
	
	/*메뉴 조회*/
	@Override
	public List<BoardVo> getMenuList(HashMap<String, Object> map) {
		
		List<BoardVo> list = boardDao.getMenuList(map);
		
		return list;
	}
	/*게시판 조회*/
	@Override
	public List<BoardVo> getBoardList(HashMap<String, Object> map) {

		int p_nowpage = Integer.valueOf((String)map.get("p_nowpage"));
		int p_pagecount = Integer.parseInt((String) map.get("p_pagecount")); 
		int p_pagetotalcount = 3; 
		int p_pagegrpnum = Integer.valueOf((String)map.get("p_pagegrpnum"));

		List<BoardVo> list = boardDao.getBoardList(map);
		
		int p_recordcount = (int) map.get("p_recordcount");  
		
		BoardPaging bp = new BoardPaging(p_nowpage,p_pagecount,p_recordcount, p_pagetotalcount,p_pagegrpnum);
		BoardVo vo = bp.getBoardPagingInfo();
		
		vo.setB_menu_id((String)map.get("b_menu_id"));
		map.put("pageBoardVo", vo);
		
		return list;
	}
	/*공지사항 조회*/
	@Override
	public List<BoardVo> noticeList(HashMap<String, Object> map) {
		List<BoardVo> list = boardDao.noticeList(map);
		return list;
	}
	/*공지사항 추가*/
	@Override
	public void noticeWrite(HashMap<String, Object> map, HttpServletRequest request) {
		System.out.println("BoardService"+map);
		//1.파일업로드 비즈니스 로직 처리		
				
				CheckFileName checkFile = new CheckFileName();
				
				System.out.println("파일ㅇㅇㅇㅇㅇㅇㅇ"+map);
				
				String filePath="h:\\Upload\\";
				//업로드된 파일이 저장될 경로 지정
				// service 는 DB와 관련되지 않는 내용을 처리한다.파일 업로드는 DB와 관련없다. 
				// repository, CRUD는 DB와 관련된 정보. DAO에는 CRUD에 관련된 내용만
				
				
				MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest) request; 
				Iterator<String> iterator = multipartHttpServletRequest.getFileNames();
				
				
				MultipartFile multipartFile = null;
				
				//여러개의 파일 처리
				List<String> fileNames = new ArrayList<String>();
				List<String> fileExts = new ArrayList<String>();
				List<String> sFileNames = new ArrayList<String>();
				//배열은 초기에 갯수를 정해줘야 하는데 ArraryList는 동적으로 변하니깐 ArrayList를 사용한다.
			    
			      String fileName = null;
			      String orgFileName = null;
			      String fileExt = null;
			      String sFileName = null;

				
				while(iterator.hasNext()) {
					//반복자에 대해서 자료가 있는지 없는지를 묻는거고 true이면 아래로 간다.
					multipartFile = multipartHttpServletRequest.getFile(iterator.next());
					//next는 현재줄을 읽고 다음줄로 가라, 인데 현재 파일을 읽어와서 그것을 multipartFile로 지정해라. 
					
					if(!multipartFile.isEmpty()) {
						//그 파일이 있는지 없는지 확인하고, 있다면 !not을 붙이고
						fileName = multipartFile.getOriginalFilename();
						
						
						orgFileName = fileName.substring(0,fileName.lastIndexOf("."));
						// . 앞에까지가 파일 이름이고
						fileExt = fileName.substring(fileName.lastIndexOf("."));
						// .을 포함해서 뒤에 내용가져오고

						sFileName = checkFile.getFileName(filePath,orgFileName, fileExt);
						//fileName으로 저장된 폴더에서 중복된 파일이 있는경우 처리.
						//만약에 같은 파일을 업로드 했을경우 계속 엎어쓰기가 되니깐 그것을 처리하기 위해서 새로운 클래스를 만들어줌.
						System.out.println("1"+fileName   );
						fileNames.add(fileName); // ArrayList에 추가
						fileExts.add(fileExt); // ArrayList에 추가
						sFileNames.add(sFileName); // ArrayList에 추가
						System.out.println("2"+fileNames.get(0));
						
						map.put("filename", fileNames); //파일이름
						System.out.println("3"+map   );
						map.put("fileext", fileExts); //확장자이름
						map.put("sfilename", sFileNames); //전체 이름
						
						
						File file = new File(filePath+sFileName);
						
						System.out.println("4"+file);
						
						//multipartFile.transferTo(file); try catch
						try {
							multipartFile.transferTo(file);
							//이 부분에서 파일을 저장한다.
						} catch (IllegalStateException | IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
					}//if
					
				}//while 
				System.out.println("filename찾기!!!!"+map );
		boardDao.noticeWrite(map);
	}
	/*공지사항 삭제*/
	@Override
	public void noticeDelete(HashMap<String, Object> map) {
		 boardDao.noticeDelete(map);
		
	}
	/*공지사항 수정 리스트*/
	@Override
	public List<BoardVo> noticeUpdateForm(HashMap<String, Object> map) {
		List<BoardVo> list = boardDao.noticeUpdateForm(map);
		return list;
	}
	/*공지사항 업데이트*/
	@Override
	public void noticeUpdate(HashMap<String, Object> map) {
		boardDao.noticeUpdate(map);
		
	}
	/*문의사항 답글*/
	@Override
	public void SetCommnet(HashMap<String, Object> map) {
		boardDao.SetCommnet(map);
	}
	/*파일리스트*/
	@Override
	public List<FilesVo> getFileList(HashMap<String, Object> map) {
		List<FilesVo> filelist =boardDao.getFileList(map);
		return filelist;
	}
	
	
	
	

}
