package com.spring.login.dao.impl;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.login.dao.LoginDao;
import com.spring.login.vo.UserVo;

@Repository("loginDao")
public class LoginDaoImpl implements LoginDao {

	@Autowired
	private SqlSession sqlSession;

	/* 로그인 처리 */
	@Override
	public UserVo doLogin(HashMap<String, Object> map) {
		
		sqlSession.selectOne("Login.DoLogin", map);
		List<UserVo> list = (List<UserVo>) map.get("result");
		UserVo vo = null;

		if (list.size() != 0) {
			vo = list.get(0);
		}
		return vo;
	}

}
