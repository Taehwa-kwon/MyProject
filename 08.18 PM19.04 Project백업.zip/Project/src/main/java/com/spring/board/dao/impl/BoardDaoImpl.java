package com.spring.board.dao.impl;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.board.dao.BoardDao;
import com.spring.board.vo.BoardVo;

@Repository("boardDao")
public class BoardDaoImpl implements BoardDao{

	@Autowired
	private SqlSession sqlSession;

	/*메뉴 조회*/
	@Override
	public List<BoardVo> getMenuList(HashMap<String, Object> map) {
		sqlSession.selectOne("Board.MenuList",map);
		
		
		List<BoardVo> list = (List<BoardVo>) map.get("result");
		System.out.println("확인확인 "+list);
		return list;
	}
	/*게시판 조회*/
	@Override
	public List<BoardVo> getBoardList(HashMap<String, Object> map) {
		//b_menu_id=MENU01&p_nowpage=1&p_pagecount=10&p_pagegrpnum=1
		sqlSession.selectOne("Board.BoardList",map);
		List<BoardVo> list = (List<BoardVo>) map.get("result");
		
		return list;
	}
	/*공지사항 조회*/
	@Override
	public List<BoardVo> noticeList(HashMap<String, Object> map) {
		sqlSession.selectOne("Board.noticeList",map);
		List<BoardVo> list = (List<BoardVo>) map.get("result");
		return list;
	}
	/*공지사항 추가*/
	@Override
	public void noticeWrite(HashMap<String, Object> map) {
		sqlSession.insert("Board.noticeWrite",map);
//b_menu_id=MENU01&b_writer=작성자,b_title, b_cont, b_bnum,b_lvl, b_step, b_nref
	}
	/*공지사항 삭제*/
	@Override
	public void noticeDelete(HashMap<String, Object> map) {
		sqlSession.update("Board.noticeDelete", map);
		
	}
	/*공지사항 수정 리스트*/
	@Override
	public List<BoardVo> noticeUpdateForm(HashMap<String, Object> map) {
		sqlSession.selectOne("Board.noticeUpdateForm",map);
		List<BoardVo> list = (List<BoardVo>) map.get("result");
		return list;
	}
	/*공지사항 업데이트*/
	@Override
	public void noticeUpdate(HashMap<String, Object> map) {
		sqlSession.update("Board.noticeUpdate", map);
		
	}
	/*문의사항 답글*/
	@Override
	public void SetCommnet(HashMap<String, Object> map) {
		
		sqlSession.insert("Board.SetCommnet",map);
	}
	
	
	
	   
	
	
	

	
}
