package com.spring.login.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.spring.admin.vo.UsersVo;
import com.spring.login.dao.LoginDao;
import com.spring.login.service.LoginService;

@Controller
public class LoginController {

	@Autowired
	private LoginService loginService;
	
	/*메인페이지*/
	@RequestMapping(value="/")  //login
	public String loginForm(){
		return "/login/loginForm";  
	}
	/*로그인 처리*/
	@RequestMapping(value="/loginProcess")
	public String loginProcess(@RequestParam HashMap<String,Object> map, HttpSession session) {
		String returnURL= "";
		 if (session.getAttribute("/")!=null ) {
				session.removeAttribute("/");//로그인이 중복되면 안되니껭 요롷구롬 초기화 하는거징 ㅋㅋㅋ
		 }
		 
		 UsersVo vo = loginService.login(map);
		
		if( vo!=null ) {
			session.setAttribute("login", vo);
			
			returnURL = "redirect:/adminMain";
		} else {
			returnURL = "/login/loginForm";
		}
		return returnURL;
	}
	/*로그아웃 처리*/ 
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.removeAttribute("login");
		session.invalidate();
		
		return "redirect:/";
	}
	
	
	
	
	
	
	
	/*						---							*/
	
	
	
	@RequestMapping("/RegisterForm")
	public String registerForm()	{
		return "registerForm";
	}
	
	@RequestMapping("/IdCheck")
	@ResponseBody
	public HashMap<String, Object> idCheck(String u_id)	{
		HashMap<String, Object> map = new HashMap<>();
		
		int checkVal = loginService.getIdCheck(u_id);
		
		return map;
	}
	
	@RequestMapping("/Register")
	public ModelAndView register(@RequestParam HashMap<String, Object> map)	{

		// 유효성 검사
		loginService.getValidation(map);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("client/home");
		return mv;
	}
	
	@RequestMapping("/FindInfo")
	public String findInfo()	{
		return "findInfo";
	}
	
	
	
}
