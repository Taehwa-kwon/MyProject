package com.spring.admin.dao;

import java.util.HashMap;
import java.util.List;

import com.spring.admin.vo.SeatsVo;
import com.spring.admin.vo.TicketsVo;
import com.spring.admin.vo.UsersVo;

public interface AdminDao {

	/* 회원 리스트 조회 */
	List<UsersVo> getList(HashMap<String, Object> map);

	/* 회원 삭제 */
	void delete(HashMap<String, Object> map);

	/* 회원 수정 */
	void updateList(HashMap<String, Object> map);

	List<TicketsVo> getTicketList(HashMap<String, Object> map);

	void delTicketList(HashMap<String, Object> map);

	void updateTicket(HashMap<String, Object> map);

	void addTicket(HashMap<String, Object> map);
	/*
	 * 열람실 리스트 출력
	 *  List<SeatsVo> getRoomList(HashMap<String, Object> map);
	 */
	
	 /*좌석 리스트 출력*/
	List<SeatsVo> getSeatList(HashMap<String, Object> map);

	List<SeatsVo> getRooms(HashMap<String, Object> map);

	

	void updateSeat(HashMap<String, Object> map);

	List<TicketsVo> getSaleList(HashMap<String, Object> map);

	

}
