package com.spring.login.service;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.spring.admin.vo.UsersVo;


public interface LoginService {
	/*로그인 처리*/
	UsersVo login(HashMap<String, Object> map);
	
	
	
	void getValidation(HashMap<String, Object> map);

	int getIdCheck(String u_id);
	


	

	UsersVo getView(HashMap<String, Object> map);
	


	



	
	
	

}
