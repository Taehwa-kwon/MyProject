package com.spring.admin.vo;

public class UsersVo {
     int u_idx; //인덱스
	 String u_id; //아이디
	 String u_pw; //비밀번호
	/* String u_pw2; */
	 String u_name; //이름
	 int u_age; //나이
	 String u_gender; //성별
	 String u_tel; //전화
	 String u_question; //질문
	 String u_answer; //답변
	 String d_id; //등급 아이디
	public int getU_idx() {
		return u_idx;
	}
	public void setU_idx(int u_idx) {
		this.u_idx = u_idx;
	}
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public String getU_pw() {
		return u_pw;
	}
	public void setU_pw(String u_pw) {
		this.u_pw = u_pw;
	}

	/*
	 * public String getU_pw2() { return u_pw2; } public void setU_pw2(String u_pw2)
	 * { this.u_pw2 = u_pw2; }
	 */
	public String getU_name() {
		return u_name;
	}
	public void setU_name(String u_name) {
		this.u_name = u_name;
	}
	public int getU_age() {
		return u_age;
	}
	public void setU_age(int u_age) {
		this.u_age = u_age;
	}
	public String getU_gender() {
		return u_gender;
	}
	public void setU_gender(String u_gender) {
		this.u_gender = u_gender;
	}
	public String getU_tel() {
		return u_tel;
	}
	public void setU_tel(String u_tel) {
		this.u_tel = u_tel;
	}
	public String getU_question() {
		return u_question;
	}
	public void setU_question(String u_question) {
		this.u_question = u_question;
	}
	public String getU_answer() {
		return u_answer;
	}
	public void setU_answer(String u_answer) {
		this.u_answer = u_answer;
	}
	public String getD_id() {
		return d_id;
	}
	public void setD_id(String d_id) {
		this.d_id = d_id;
	}
	
	
	@Override
	public String toString() {
		return "UsersVo [u_idx=" + u_idx + ", u_id=" + u_id + ", u_pw=" + u_pw + /* ", u_pw2=" + u_pw2 + */ ", u_name="
				+ u_name + ", u_age=" + u_age + ", u_gender=" + u_gender + ", u_tel=" + u_tel + ", u_question="
				+ u_question + ", u_answer=" + u_answer + ", d_id=" + d_id + "]";
	}
	
	 
	 
	
	

	
}
