package com.spring.admin.dao.impl;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.admin.dao.AdminDao;
import com.spring.admin.vo.SeatsVo;
import com.spring.admin.vo.TicketsVo;
import com.spring.admin.vo.UsersVo;

@Repository("adminDao")
public class AdminDaoImpl implements AdminDao {

	@Autowired
	private SqlSession sqlSession;

	/* 회원 리스트 조회 */
	@Override
	public List<UsersVo> getList(HashMap<String, Object> map) {
		sqlSession.selectList("Admin.UserList", map);
		List<UsersVo> list = (List<UsersVo>) map.get("result");
		return list;
	}

	/* 회원 삭제 */
	@Override
	public void delete(HashMap<String, Object> map) {
		sqlSession.delete("Admin.UserDelete", map);
	}

	/* 회원 수정 */
	@Override
	public void updateList(HashMap<String, Object> map) {
		int a = sqlSession.update("Admin.UserUpdate", map);
		System.out.println(a);
	}

	/* 티켓 리스트 조회 */
	@Override
	public List<TicketsVo> getTicketList(HashMap<String, Object> map) {
		sqlSession.selectList("Admin.TicketList", map);
		List<TicketsVo> list = (List<TicketsVo>) map.get("result");
		return list;

	}

	/* 티켓 리스트 삭제 */
	@Override
	public void delTicketList(HashMap<String, Object> map) {
		sqlSession.delete("Admin.TicketDelete", map);

	}

	/* 티켓 리스트 수정 */
	@Override
	public void updateTicket(HashMap<String, Object> map) {
		sqlSession.update("Admin.TicketUpdate", map);

	}

	/* 티켓 리스트 추가 */
	@Override
	public void addTicket(HashMap<String, Object> map) {

		sqlSession.insert("Admin.TicketAdd", map);
		
		System.out.println( (String) map.get("o_err_msg") );

	}

	/*
	 * 열람실 리스트 추가
	 * 
	 * @Override public List<SeatsVo> getRoomList(HashMap<String, Object> map) {
	 * 
	 * sqlSession.selectList("Admin.RoomList", map); List<SeatsVo> roomList =
	 * (List<SeatsVo>) map.get("result"); System.out.println(roomList); return
	 * roomList; }
	 */

	/* 좌석 리스트 추가 */
	@Override
	public List<SeatsVo> getSeatList(HashMap<String, Object> map) {
		sqlSession.selectList("Admin.SeatList", map);
		List<SeatsVo> seatList = (List<SeatsVo>) map.get("result");
		return seatList;
	}

	@Override
	public List<SeatsVo> getRooms(HashMap<String, Object> map) {
		sqlSession.selectList("Admin.RoomList", map);
		List<SeatsVo> roomList = (List<SeatsVo>) map.get("result");
		return roomList;
	}

	

	@Override
	public void updateSeat(HashMap<String, Object> map) {
		sqlSession.update("Admin.SeatUpdate", map);
		
	}

	@Override
	public List<TicketsVo> getSaleList(HashMap<String, Object> map) {
		sqlSession.selectList("Admin.SaleList", map);
		List<TicketsVo> saleList = (List<TicketsVo>) map.get("result");
		System.out.println("다오임플 :"+saleList);
		return saleList;
	}

	

}
