package com.spring.board.service.impl;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.board.dao.BoardDao;
import com.spring.board.service.BoardService;
import com.spring.board.vo.BoardVo;

@Service("boardService")
public class BoardServiceimpl implements BoardService {
	
	@Autowired
	private BoardDao boardDao;
	
	/*메뉴 조회*/
	@Override
	public List<BoardVo> getMenuList(HashMap<String, Object> map) {
		
		List<BoardVo> list = boardDao.getMenuList(map);
		
		return list;
	}
	/*게시판 조회*/
	@Override
	public List<BoardVo> getBoardList(HashMap<String, Object> map) {
		// b_menu_id=MENU01&p_nowpage=1&p_pagecount=10&p_pagegrpnum=1

		int p_nowpage = Integer.valueOf((String)map.get("p_nowpage"));
		int p_pagecount = Integer.parseInt((String) map.get("p_pagecount")); // 한 페이지당 n 라인
		int p_pagetotalcount = 3; // pagegrpnum=1에 대한 총 개수
		int p_pagegrpnum = Integer.valueOf((String)map.get("p_pagegrpnum"));
		/*
		 * leftBar에서 오는 p_nowpage , p_pagecount , p_pagegrpnum을 getParameter이니깐 String으로
		 * 받고 pagecount는 연산을 해야해서 int로 바꿔주고 mapper에서 INTEGER로 바꾼다.
		 */

		List<BoardVo> list = boardDao.getBoardList(map);
		
		int p_recordcount = (int) map.get("p_recordcount"); // 총 자료 개수 
		
		BoardPaging bp = new BoardPaging(p_nowpage,p_pagecount,p_recordcount, p_pagetotalcount,p_pagegrpnum);
		
		
		BoardVo vo = bp.getBoardPagingInfo();
		
		vo.setB_menu_id((String)map.get("b_menu_id"));
		map.put("pageBoardVo", vo);
		
		return list;
	}
	/*공지사항 조회*/
	@Override
	public List<BoardVo> noticeList(HashMap<String, Object> map) {
		List<BoardVo> list = boardDao.noticeList(map);
		return list;
	}
	/*공지사항 추가*/
	@Override
	public void noticeWrite(HashMap<String, Object> map) {
		 boardDao.noticeWrite(map);
	}
	/*공지사항 삭제*/
	@Override
	public void noticeDelete(HashMap<String, Object> map) {
		 boardDao.noticeDelete(map);
		
	}
	/*공지사항 수정 리스트*/
	@Override
	public List<BoardVo> noticeUpdateForm(HashMap<String, Object> map) {
		List<BoardVo> list = boardDao.noticeUpdateForm(map);
		return list;
	}
	/*공지사항 업데이트*/
	@Override
	public void noticeUpdate(HashMap<String, Object> map) {
		boardDao.noticeUpdate(map);
		
	}
	/*문의사항 답글*/
	@Override
	public void SetCommnet(HashMap<String, Object> map) {
		boardDao.SetCommnet(map);
	}
	
	
	

}
