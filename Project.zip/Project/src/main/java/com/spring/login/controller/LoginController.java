package com.spring.login.controller;

import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.login.service.LoginService;
import com.spring.login.vo.UserVo;

@Controller
public class LoginController {

	static int count = 0;

	@Autowired
	private LoginService loginService;
	
	/* 메인(로그인) 페이지 */
	@RequestMapping(value="/") // login
	public String loginForm() {
		return "/login/loginForm";
	}
	
	/* 로그인 처리 */
	@RequestMapping(value="/LoginProcess", method=RequestMethod.POST)
	public ModelAndView loginProcess(@RequestParam HashMap<String, Object> map, HttpSession session) {
		
		if (session.getAttribute("/") != null) {
			session.removeAttribute("/");
		}

		UserVo vo = loginService.doLogin(map);
		System.out.println(vo);
		ModelAndView mv = new ModelAndView();

		if (vo != null) {

			count = 0;
			session.setAttribute("login", vo);

			if (map.get("u_id").equals("admin")) {
				mv.addObject("u_id",vo.getU_id());
				mv.setViewName("redirect:/adminMain");
			}
			else {
				mv.addObject("u_id",vo.getU_id());
				mv.setViewName("redirect:/adminMain");
			}
		} else {
			mv.addObject("msg", "아이디/비밀번호가 잘못 입력되었습니다. <br />" + (++count) + "회 틀렸습니다");
			mv.setViewName("/login/loginForm");
		}

		return mv;
	}
	
	/* 로그아웃 처리 */
	@RequestMapping("/Logout")
	public ModelAndView logout(HttpSession session)	{
		
		ModelAndView mv = new ModelAndView();

		session.removeAttribute("login");
		session.invalidate();
		mv.setViewName("redirect:/");

		return mv;
	}
	
}
