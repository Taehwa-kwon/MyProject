package com.spring.login.dao;

import java.util.HashMap;

import com.spring.login.vo.UserVo;

public interface LoginDao {

	/* 로그인 처리 */
	UserVo doLogin(HashMap<String, Object> map);


}
