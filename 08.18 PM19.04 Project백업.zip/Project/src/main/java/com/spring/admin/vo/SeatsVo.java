package com.spring.admin.vo;

public class SeatsVo {
	
	//Seats
	String s_id;
	String sh_end_time;
	String r_id;
	String s_status;
	
	//Rooms
	String u_id;
	String r_cap;
	String r_gender;
	
	//getRooms에 필요한 필드
	String r_name;
	int sum_seats;
	int usable_seats;
	int unusable_seats;
	
	//getSeats에 필요한 필드
	String availability;
	String bigo;
	
	
	public String getS_id() {
		return s_id;
	}
	public void setS_id(String s_id) {
		this.s_id = s_id;
	}
	public String getSh_end_time() {
		return sh_end_time;
	}
	public void setSh_end_time(String sh_end_time) {
		this.sh_end_time = sh_end_time;
	}
	public String getR_id() {
		return r_id;
	}
	public void setR_id(String r_id) {
		this.r_id = r_id;
	}
	public String getS_status() {
		return s_status;
	}
	public void setS_status(String s_status) {
		this.s_status = s_status;
	}
	public String getR_name() {
		return r_name;
	}
	public void setR_name(String r_name) {
		this.r_name = r_name;
	}
	
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public String getR_cap() {
		return r_cap;
	}
	public void setR_cap(String r_cap) {
		this.r_cap = r_cap;
	}
	public String getR_gender() {
		return r_gender;
	}
	public void setR_gender(String r_gender) {
		this.r_gender = r_gender;
	}
	
	public int getSum_seats() {
		return sum_seats;
	}
	public void setSum_seats(int sum_seats) {
		this.sum_seats = sum_seats;
	}
	public int getUsable_seats() {
		return usable_seats;
	}
	public void setUsable_seats(int usable_seats) {
		this.usable_seats = usable_seats;
	}
	public int getUnusable_seats() {
		return unusable_seats;
	}
	public void setUnusable_seats(int unusable_seats) {
		this.unusable_seats = unusable_seats;
	}
	
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public String getBigo() {
		return bigo;
	}
	public void setBigo(String bigo) {
		this.bigo = bigo;
	}
	
	@Override
	public String toString() {
		return "SeatsVo [s_id=" + s_id + ", sh_end_time=" + sh_end_time + ", r_id=" + r_id + ", s_status=" + s_status
				+ ", u_id=" + u_id + ", r_cap=" + r_cap + ", r_gender=" + r_gender + ", r_name=" + r_name
				+ ", sum_seats=" + sum_seats + ", usable_seats=" + usable_seats + ", unusable_seats=" + unusable_seats
				+ ", availability=" + availability + ", bigo=" + bigo + "]";
	}
	
	
	
	
	
	
	
	
}
