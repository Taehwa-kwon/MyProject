package com.spring.admin.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.spring.admin.service.AdminService;
import com.spring.admin.vo.SeatsVo;
import com.spring.admin.vo.TicketsVo;
import com.spring.admin.vo.UsersVo;

@Controller
public class AdminController {

	@Autowired
	private AdminService adminService;

	//--------------------------- 메인 ---------------------------------------------
	/* 관리자 메인 페이지 */
	@RequestMapping("/adminMain")
	public String adminMain(HashMap<String, Object> map, HttpSession session) {
		return "/admin/Main";
	}
	
	//---------------------------- 메인 끝-----------------------------------------------
	
	
	//---------------------------- 회원 ----------------------------------------------
	
	/* 회원 리스트 조회 */
	@RequestMapping("/adminList")
	public ModelAndView adminList(HashMap<String, Object> map) {
		ModelAndView mv = new ModelAndView();
		List<UsersVo> userlist = adminService.getList(map);
		mv.setViewName("/admin/adminList");
		mv.addObject("userList", userlist);

		return mv;

	}
	

	/* 회원 삭제 */
	@RequestMapping("/adminDel")
	public String delete(@RequestParam HashMap<String, Object> map) {
		adminService.delete(map);
		return "redirect:/adminList";

	}

	/* 회원 수정 화면 */
	@RequestMapping("UpdateForm")
	public ModelAndView updateForm(@RequestParam HashMap<String, Object> map) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("/admin/updateForm");
		mv.addObject("userVo", map);
		return mv;

	}

	/* 회원 수정 */
	@RequestMapping("/Update")
	public String update(@RequestParam HashMap<String, Object> map) {

		adminService.updateList(map);

		return "redirect:/adminList";
	}
	
	//----------------------------- 회원 끝 -----------------------------------------

	
	//----------------------------- 티켓 --------------------------------------------
	/* 티켓 리스트 */
	@RequestMapping("/adminTicket")
	public ModelAndView adminTicket(@RequestParam HashMap<String, Object> map) {

		ModelAndView mv = new ModelAndView();

		List<TicketsVo> ticketlist = adminService.getTicketList(map);
		mv.setViewName("/admin/adminTicket");
		mv.addObject("ticketList", ticketlist);

		return mv;

	}

	/* 티켓 삭제 */
	@RequestMapping("/ticketDel")
	public String ticketDel(@RequestParam HashMap<String, Object> map) {
		adminService.delTicketList(map);
		
		return "redirect:/adminTicket";

	}

	/* 티켓 수정 화면 */
	@RequestMapping("ticketForm")
	public ModelAndView ticketForm(@RequestParam HashMap<String, Object> map) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("/admin/ticketForm");
		mv.addObject("ticketsVo", map);
		return mv;

	}

	/* 티켓 수정 */
	@RequestMapping("/TicketUpdate")
	public String updateTicket(@RequestParam HashMap<String, Object> map) {

		adminService.updateTicket(map);

		return "redirect:/adminTicket";
	}

	/* 티켓 추가 */
	@RequestMapping("/TicketAdd")
	public String addTicket(@RequestParam HashMap<String, Object> map) {

		adminService.addTicket(map);
		return "redirect:/adminTicket";
	}
	
	//------------------------------ 티켓 끝 ----------------------------------------

	
	//------------------------------ 열람실 -----------------------------------------------
	
	/* 열람실 출력*/
	 @RequestMapping("/adminRoom")
	   public ModelAndView getRooms(@RequestParam HashMap<String, Object> map, HttpSession session)      {
	      
	      List<SeatsVo> roomList = adminService.getRooms(map);
	      
	      ModelAndView mv = new ModelAndView();

	      mv.addObject("roomList", roomList);
	      
	      mv.setViewName("admin/adminRoom");
	      return mv;
	   }

	/* 열람실 내 좌석 리스트 */
	@RequestMapping("/GetSeats")
	@ResponseBody
	public List<SeatsVo> getSeats(@RequestParam HashMap<String, Object> map) {
		
		List<SeatsVo> seatList = adminService.getSeats(map);
		System.out.println(seatList);

		return seatList;
	}
	
	/* 열람실 내 좌석 상태 변경(고장 -> 양호 , 양호-> 고장)*/
	@RequestMapping("/SeatUpdate")
	public String updateSeat(@RequestParam HashMap<String, Object> map) {
		adminService.updateSeat(map);
		return "redirect:/adminRoom";
		
	}
	
	
	//---------------------------------- 열람실 끝 ----------------------------------------
	
	
	//---------------------------------- 매출------------------------------------------
	/*매출 리스트*/
	@RequestMapping("/adminSale")
	public ModelAndView getSaleList(@RequestParam HashMap<String, Object> map) {
		
		ModelAndView mv = new ModelAndView();
		List<TicketsVo> saleList = adminService.getSaleList(map);
		mv.setViewName("/admin/adminSale");
		mv.addObject("saleList", saleList);
		System.out.println(mv);

		return mv;
		
	
	}
	
}
