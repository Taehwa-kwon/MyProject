package com.spring.login.service.impl;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.login.dao.LoginDao;
import com.spring.login.service.LoginService;
import com.spring.login.vo.UserVo;

@Service("loginService")
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginDao loginDao;
	
	/* 로그인 처리 */
	@Override
	public UserVo doLogin(HashMap<String, Object> map) {
		UserVo vo = loginDao.doLogin(map);
		return vo;
	}

}
