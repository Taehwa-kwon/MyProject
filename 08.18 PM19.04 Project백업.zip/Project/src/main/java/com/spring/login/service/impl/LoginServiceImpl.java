package com.spring.login.service.impl;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.admin.vo.UsersVo;
import com.spring.login.dao.LoginDao;
import com.spring.login.service.LoginService;


@Service("loginService")
public class LoginServiceImpl implements LoginService {
	
	@Autowired
	private LoginDao loginDao;
	/*로그인 처리*/
	@Override
	public UsersVo login(HashMap<String, Object> map) {
		UsersVo vo = loginDao.login(map);
		return vo;
	}

	@Override
	public UsersVo getView(HashMap<String, Object> map) {
		UsersVo usersVo = loginDao.getView(map);
		return usersVo;
	}
	
	
	
	
	
	/*						---							*/
	
	@Override
	public int getIdCheck(String u_id) {
		int num = 0;	// 숫자
		int en  = 0;	// 영어
		int ko  = 0;	// 한글
		int etc = 0;	// 특수문자
		
		char [] useridChar = u_id.toCharArray();
		for (int i = 0; i < useridChar.length; i++) {
			if ( useridChar[i] >= 0 && useridChar[i] <= 9 )	{
				num += 1;
			} else if ( useridChar[i] >= 'A' && useridChar[i] <= 'z' )	{
				en  += 1;
			} else if ( useridChar[i] >= '\uAC00' && useridChar[i] <= '\uD7A3' ) {
				ko += 3;
			} else 
				etc += 1;
		}
		
		//int [] chars = {num, en, ko, etc};
		
		if ( u_id.equals("") )	{
			return 1;			// 아이디를 입력하세요. (미입력 상태)
		}
		else if ( ko != 0 || etc != 0 )	{
			return 2;			// 한글 또는 특수문자를 사용할 수 없습니다.
		}
		else if ( num + en > 20 )	{
			return 3;			// 아이디 글자수가 너무 많습니다.
		}
		
		//int dupCnt = basicDao.idCheck(u_id);
		return 0;
	}

	@Override
	public void getValidation(HashMap<String, Object> map) {
		
	}
	

	

	

	
}
