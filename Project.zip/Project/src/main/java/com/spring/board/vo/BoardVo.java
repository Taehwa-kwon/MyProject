package com.spring.board.vo;

public class BoardVo {
	int b_idx; //글 Index
	int se_b_idx; //공지사항 문의사항 구분 ROWNUMBER
	String b_menu_id; //공지,Q/A 구분
	String b_menu_name; //공지,Q/A 구분
	
	String b_title; //
	String b_cont;
	String b_writer;
	String b_regdate;
	int b_readcount;
	int b_bnum;
	int b_lvl;
	int b_step;
	int b_nref;
	int b_delnum;
	
	String m_menu_name;
	int m_menu_seq;
	
	// 페이징 관련 변수 ( 게시판 하단에 1,2,3,4,5 이런 페이지)
	private int p_nowpage; // 현재 페이지 정보
	private int p_pagecount; // 1페이지에 보여줄 자료 라인수

	private int p_prevnowpage; // 이전 페이지 정보
	private int p_nextnowpage; // 다음 페이지 정보

	private int p_recordcount; // 전체 자료수
	private int p_totalpagecount; // 전체 페이지수

	private int p_pagestartnum; // 페이지 시작 번호 ( 단일 화면 )
	private int p_pageendnum; // 페이지 끝 번호 ( 단일 화면 )
	private int p_pagegrpnum; // 페이지그룹번호

	private boolean p_isshowpageprev; // ◀ ▶ 이거 표시
	private boolean p_isshowpagenext;
	
	//오류코드
	String o_err_code; 
	String o_err_msg;
	
	String upfile;
	
	
	
	public String getUpfile() {
		return upfile;
	}
	public void setUpfile(String upfile) {
		this.upfile = upfile;
	}
	public String getO_err_code() {
		return o_err_code;
	}
	public void setO_err_code(String o_err_code) {
		this.o_err_code = o_err_code;
	}
	public String getO_err_msg() {
		return o_err_msg;
	}
	public void setO_err_msg(String o_err_msg) {
		this.o_err_msg = o_err_msg;
	}
	public int getSe_b_idx() {
		return se_b_idx;
	}
	public void setSe_b_idx(int se_b_idx) {
		this.se_b_idx = se_b_idx;
	}
	public int getB_idx() {
		return b_idx;
	}
	public void setB_idx(int b_idx) {
		this.b_idx = b_idx;
	}
	public String getB_menu_id() {
		return b_menu_id;
	}
	public void setB_menu_id(String b_menu_id) {
		this.b_menu_id = b_menu_id;
	}
	public String getB_title() {
		return b_title;
	}
	public void setB_title(String b_title) {
		this.b_title = b_title;
	}
	public String getB_cont() {
		return b_cont;
	}
	public void setB_cont(String b_cont) {
		this.b_cont = b_cont;
	}
	public String getB_writer() {
		return b_writer;
	}
	public void setB_writer(String b_writer) {
		this.b_writer = b_writer;
	}
	public String getB_regdate() {
		return b_regdate;
	}
	public void setB_regdate(String b_regdate) {
		this.b_regdate = b_regdate;
	}
	public int getB_readcount() {
		return b_readcount;
	}
	public void setB_readcount(int b_readcount) {
		this.b_readcount = b_readcount;
	}
	public int getB_bnum() {
		return b_bnum;
	}
	public void setB_bnum(int b_bnum) {
		this.b_bnum = b_bnum;
	}
	public int getB_lvl() {
		return b_lvl;
	}
	public void setB_lvl(int b_lvl) {
		this.b_lvl = b_lvl;
	}
	public int getB_step() {
		return b_step;
	}
	public void setB_step(int b_step) {
		this.b_step = b_step;
	}
	public int getB_nref() {
		return b_nref;
	}
	public void setB_nref(int b_nref) {
		this.b_nref = b_nref;
	}
	public int getB_delnum() {
		return b_delnum;
	}
	public void setB_delnum(int b_delnum) {
		this.b_delnum = b_delnum;
	}
	public String getM_menu_name() {
		return m_menu_name;
	}
	public void setM_menu_name(String m_menu_name) {
		this.m_menu_name = m_menu_name;
	}
	public int getM_menu_seq() {
		return m_menu_seq;
	}
	public void setM_menu_seq(int m_menu_seq) {
		this.m_menu_seq = m_menu_seq;
	}
	public int getP_nowpage() {
		return p_nowpage;
	}
	public void setP_nowpage(int p_nowpage) {
		this.p_nowpage = p_nowpage;
	}
	public int getP_pagecount() {
		return p_pagecount;
	}
	public void setP_pagecount(int p_pagecount) {
		this.p_pagecount = p_pagecount;
	}
	public int getP_prevnowpage() {
		return p_prevnowpage;
	}
	public void setP_prevnowpage(int p_prevnowpage) {
		this.p_prevnowpage = p_prevnowpage;
	}
	public int getP_nextnowpage() {
		return p_nextnowpage;
	}
	public void setP_nextnowpage(int p_nextnowpage) {
		this.p_nextnowpage = p_nextnowpage;
	}
	public int getP_recordcount() {
		return p_recordcount;
	}
	public void setP_recordcount(int p_recordcount) {
		this.p_recordcount = p_recordcount;
	}
	public int getP_totalpagecount() {
		return p_totalpagecount;
	}
	public void setP_totalpagecount(int p_totalpagecount) {
		this.p_totalpagecount = p_totalpagecount;
	}
	public int getP_pagestartnum() {
		return p_pagestartnum;
	}
	public void setP_pagestartnum(int p_pagestartnum) {
		this.p_pagestartnum = p_pagestartnum;
	}
	public int getP_pageendnum() {
		return p_pageendnum;
	}
	public void setP_pageendnum(int p_pageendnum) {
		this.p_pageendnum = p_pageendnum;
	}
	public int getP_pagegrpnum() {
		return p_pagegrpnum;
	}
	public void setP_pagegrpnum(int p_pagegrpnum) {
		this.p_pagegrpnum = p_pagegrpnum;
	}
	public boolean isP_isshowpageprev() {
		return p_isshowpageprev;
	}
	public void setP_isshowpageprev(boolean p_isshowpageprev) {
		this.p_isshowpageprev = p_isshowpageprev;
	}
	public boolean isP_isshowpagenext() {
		return p_isshowpagenext;
	}
	public void setP_isshowpagenext(boolean p_isshowpagenext) {
		this.p_isshowpagenext = p_isshowpagenext;
	}
	public String getB_menu_name() {
		return b_menu_name;
	}
	public void setB_menu_name(String b_menu_name) {
		this.b_menu_name = b_menu_name;
	}
	
	@Override
	public String toString() {
		return "BoardVo [b_idx=" + b_idx + ", se_b_idx=" + se_b_idx + ", b_menu_id=" + b_menu_id + ", b_menu_name="
				+ b_menu_name + ", b_title=" + b_title + ", b_cont=" + b_cont + ", b_writer=" + b_writer
				+ ", b_regdate=" + b_regdate + ", b_readcount=" + b_readcount + ", b_bnum=" + b_bnum + ", b_lvl="
				+ b_lvl + ", b_step=" + b_step + ", b_nref=" + b_nref + ", b_delnum=" + b_delnum + ", m_menu_name="
				+ m_menu_name + ", m_menu_seq=" + m_menu_seq + ", p_nowpage=" + p_nowpage + ", p_pagecount="
				+ p_pagecount + ", p_prevnowpage=" + p_prevnowpage + ", p_nextnowpage=" + p_nextnowpage
				+ ", p_recordcount=" + p_recordcount + ", p_totalpagecount=" + p_totalpagecount + ", p_pagestartnum="
				+ p_pagestartnum + ", p_pageendnum=" + p_pageendnum + ", p_pagegrpnum=" + p_pagegrpnum
				+ ", p_isshowpageprev=" + p_isshowpageprev + ", p_isshowpagenext=" + p_isshowpagenext + ", o_err_code="
				+ o_err_code + ", o_err_msg=" + o_err_msg + ", upfile=" + upfile + "]";
	}
	
	
	
	
	
	
}
