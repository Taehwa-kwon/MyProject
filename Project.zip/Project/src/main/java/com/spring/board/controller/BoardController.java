package com.spring.board.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.board.service.BoardService;
import com.spring.board.vo.BoardVo;
import com.spring.board.vo.FilesVo;

@Controller
public class BoardController {
	@Autowired
	private BoardService boardService;
	/*메뉴,게시판 전체 조회*/
	
	@RequestMapping("/board")
	public ModelAndView boardMain(@RequestParam HashMap<String,Object>map ) {
		ModelAndView mv = new ModelAndView();
		/*메뉴리스트*/
		List<BoardVo> MenuList = boardService.getMenuList(map);
		/*게시판리스트*/
		List<BoardVo> BoardList = boardService.getBoardList(map);

		BoardVo pageBoardVo = (BoardVo) map.get("pageBoardVo");
		
		mv.addObject("b_menu_id", map.get("b_menu_id"));
		mv.addObject("BoardList", BoardList);
		mv.addObject("MenuList", MenuList);
		mv.addObject("pageBoardVo", pageBoardVo);
		
		mv.setViewName("/board/boardMain");
		return mv;
	}
	
	/*공지사항 확인View*/
	@RequestMapping("/board/ContentView")
	public ModelAndView ContentView(@RequestParam HashMap<String,Object>map) {
		
		ModelAndView mv = new ModelAndView();
		List<BoardVo> noticeView = boardService.noticeUpdateForm(map);
		List<FilesVo> fileList = boardService.getFileList(map);//게시글의 파일 목록조회
		BoardVo vo = noticeView.get(0);
		
		mv.addObject("fileList", fileList);
		mv.addObject("noticeView", vo);
		mv.setViewName("board/noticeContent");
		
		return mv;
	}
	
	/*공지사항 조회*/
	@RequestMapping("/board/notice")
	public ModelAndView boardList(@RequestParam HashMap<String,Object>map) {
		ModelAndView mv = new ModelAndView();
		List<BoardVo> noticeWrite = boardService.noticeList(map);
		
		BoardVo vo = noticeWrite.get(0);
		
		mv.addObject("noticeWrite",vo);
		mv.setViewName("/board/noticeWriteForm");
		
		return mv;
	}
	
	/*공지사항 추가*/
	@RequestMapping("/board/noticeWrite")
	public String noticeWrite(@RequestParam HashMap<String,Object>map, HttpServletRequest request) {
		
		boardService.noticeWrite(map,request);
		
		return "redirect:/board?b_menu_id="+map.get("b_menu_id")+"&p_nowpage=1&p_pagecount=10&p_pagegrpnum=1"; 
	}
	
	/*공지사항 삭제*/
	@RequestMapping("/board/notice/delete")
	public String noticeDelete(@RequestParam HashMap<String,Object>map) {
		//b_idx=글 번호
		boardService.noticeDelete(map);
		
		return "redirect:/board?b_menu_id="+map.get("b_menu_id")+"&p_nowpage=1&p_pagecount=10&p_pagegrpnum=1";
	}
	
	/*공지사항 수정 리스트*/
	@RequestMapping("/board/notice/updateForm")
	public ModelAndView noticeUpdateForm(@RequestParam HashMap<String,Object>map) {
		
		ModelAndView mv = new ModelAndView();
		List<BoardVo> noticeView = boardService.noticeUpdateForm(map);
		BoardVo vo = noticeView.get(0);
		mv.setViewName("board/noticeUpdateForm");
		mv.addObject("noticeView", vo);
		
		return mv;
	}
	/*공지사항 수정*/
	@RequestMapping("/board/notice/update")
	public String noticeUpdate(@RequestParam HashMap<String,Object>map) {
		
		boardService.noticeUpdate(map);
		return "redirect:/board?b_menu_id="+map.get("b_menu_id")+"&p_nowpage=1&p_pagecount=10&p_pagegrpnum=1";
	}
	
	
	   @RequestMapping("/board/Question") 
	   public String SetQuestions(@RequestParam HashMap<String,Object>map) {
	      
	      boardService.SetCommnet(map);
	       
	      return "redirect:/board?b_menu_id="+map.get("b_menu_id")+"&p_nowpage=1&p_pagecount=10&p_pagegrpnum=1";
	   }
	  
	   
	   
	   @RequestMapping(value = "/download/{type}/{sfile:.+}", method = RequestMethod.GET)
		public void downloadFile(HttpServletResponse response, 
				@PathVariable("type") String type, // {} 템플릿변수
				@PathVariable("sfile") String sfile) {
		   System.out.println("여기까지 오나 ? " + type + sfile);
			String INTERNAL_FILE = sfile; // 내부 파일 명
			String EXTERNAL_FILE_PATH = "h:\\Upload\\" + sfile; // 외부 파일경로 + 파일명
			File file = null;
			if (type.equalsIgnoreCase("internal")) {
				ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
				// ClassLoader은 이 전체 현재 클래스 currentThread 현재 실행중인 쓰레드 그 클래스 정보를 가져온나.
				file = new File(classLoader.getResource(INTERNAL_FILE).getFile());
				// 이 위치정보를 가져와서 , getFile 그 파일을 가져온나.
				// 현재 실행중인 폴더에 있는것을 사용하는것이 internal.
			} else {
				file = new File(EXTERNAL_FILE_PATH);
			}

			// 다운로드할 파일이 없습니다.
			if (!file.exists()) {
				String errorMessage = "file not exists";
				// 이럴때는 HTML로 내 보내야한다. 이 error은 db에 저장되어 있는데 하드디스크에 저장되어 있지 않는 경우, 해당 오류가 발생

				// out.print(); //response.getWrite를 해야한다. 그래야 out이 가능하다.
				OutputStream outputStream = null;
				try {
					outputStream = response.getOutputStream();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					outputStream.write(errorMessage.getBytes(Charset.forName("UTF-8")));
					// 이 함수는 byte단위로 파일을 처리해야 한다. 웹은 모든 데이터를 byte단위로 처리한다.
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					outputStream.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return;
			}
			/*
			 * String mimeType = URLConnection.guessContentTypeFromName(file.getName()); //이
			 * 파일의 타입이 뭐냐, text면 text로 인식하고 바로 인식해라. excel이면 excel을 if(mimeType==null) {
			 * mimeType="application/octet-stream"; } 여기서 하려고 하는게 자료실이잖아. 내가 원하는 파일을 다운받으려고
			 * 하는데 excel이면 내 컴퓨터에 excel이 있으면 다운로드 안하고 바로 파일을 브라우저에서 excel형식으로 실행을 해버린다.
			 * 브라우저에게 다운받을 파일의 type을 알려주고, 찾아준다.
			 */

			String mimeType = "application/octet-stream";
			// 그래서 이러한 코딩을 통해서 파일을 무조건 다운로드 하여라

			// 다운로드 로직 start
			response.setContentType(mimeType);
			response.setHeader("Content-Dispostition", String.format("inline; filename=\"" + file.getName() + "\""));
			// filename은 ""안에 넣어야하는데 \" 이렇게 해야 들어감.
			response.setContentLength((int) file.length());
			InputStream inputStream = null;
			try {
				inputStream = new BufferedInputStream(new FileInputStream(file));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				FileCopyUtils.copy(inputStream, response.getOutputStream());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// 이 내용이 핵심문장이다. copy는 byte단위로 해서 다 copy하고 close both streams < 이렇게 하면
			// inputStream.close() outputStream.close() 둘다 생략이 가능하다.

		}
	
	
	
	

}
