package com.spring.login.service;

import java.util.HashMap;

import com.spring.login.vo.UserVo;

public interface LoginService {

	/* 로그인 처리 */
	UserVo doLogin(HashMap<String, Object> map);

}
