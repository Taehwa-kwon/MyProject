package com.spring.login.dao.impl;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.admin.vo.UsersVo;
import com.spring.login.dao.LoginDao;



@Repository("loginDao")
public class LoginDaoImpl implements LoginDao {

	@Autowired
	private SqlSession sqlSession;
	/*로그인 처리*/
	@Override
	public UsersVo login(HashMap<String, Object> map) {
		sqlSession.selectList("User.Login",map);
		 List<UsersVo> list=  (List<UsersVo>) map.get("result");
		 UsersVo vo = null;
		 if(list.size()!=0) {
			 vo = list.get(0);
		 } 
		return vo;
	}
	
	
	/*로그인 검사*/
	@Override
	public int idCheck(String u_id) {
		HashMap<String, Object> map = new HashMap<>();
		map.put("u_id", u_id);

		return 0;
	}
	
	

	@Override
	public UsersVo getView(HashMap<String, Object> map) {

		//sqlSession.selectList("User.UserUpdate", map);
		//List<UsersVo> userList = (List<UsersVo>) map.get("result");
		//UsersVo usersVo = userList.get(0);
		//System.out.println(usersVo);
		return null;//usersVo;
	}



	


	
	

}
