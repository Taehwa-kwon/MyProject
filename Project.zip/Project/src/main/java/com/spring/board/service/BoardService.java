package com.spring.board.service;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.spring.board.vo.BoardVo;
import com.spring.board.vo.FilesVo;

public interface BoardService {
	/*메뉴 조회*/
	List<BoardVo> getMenuList(HashMap<String, Object> map);
	/*게시판 조회*/
	List<BoardVo> getBoardList(HashMap<String, Object> map);
	/*공지사항 조회*/
	List<BoardVo> noticeList(HashMap<String, Object> map);
	/*공지사항 추가*/
	void noticeWrite(HashMap<String, Object> map, HttpServletRequest request);
	/*공지사항 삭제*/
	void noticeDelete(HashMap<String, Object> map);
	/*공지사항 수정 리스트*/
	List<BoardVo> noticeUpdateForm(HashMap<String, Object> map);
	/*공지사항 업데이트*/
	void noticeUpdate(HashMap<String, Object> map);
	/*문의사항 답글*/
	void SetCommnet(HashMap<String, Object> map);
	/*파일리스트*/
	List<FilesVo> getFileList(HashMap<String, Object> map);
	
	

	
	
	

}
